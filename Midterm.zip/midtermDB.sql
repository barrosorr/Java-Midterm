CREATE DATABASE midtermDB;

USE midtermDB;

CREATE TABLE diagnosis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    patient_id VARCHAR(255) NOT NULL,
    symptoms VARCHAR(255),
    diagnosis VARCHAR(255),
    medicines VARCHAR(255),
    ward_required BOOLEAN
);